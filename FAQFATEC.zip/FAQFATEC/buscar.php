<?php
// Verifica se a variável 'q' (query) está presente na URL
if (isset($_GET['q'])) {
    // Recupera a consulta de pesquisa da URL
    $query = $_GET['q'];

    // Conecta ao banco de dados (substitua pelos detalhes do seu banco de dados)
    $conexao = new mysqli("localhost", "root", "", "faqfatec");

    // Verifica a conexão
    if ($conexao->connect_error) {
        die("Falha na conexão: " . $conexao->connect_error);
    }

    // Consulta para buscar perguntas com base na pesquisa
    $queryPerguntas = "SELECT Categorias.NomeCategoria, Perguntas.PerguntaTexto, Respostas.RespostaTexto
                      FROM Perguntas
                      INNER JOIN Categorias ON Perguntas.CategoriaID = Categorias.CategoriaID
                      INNER JOIN Respostas ON Perguntas.PerguntaID = Respostas.PerguntaID
                      WHERE Perguntas.status = 'respondida' AND (Perguntas.PerguntaTexto LIKE '%$query%' OR Respostas.RespostaTexto LIKE '%$query%')
                      ORDER BY Perguntas.dataCriacao DESC";

    $resultadoPerguntas = $conexao->query($queryPerguntas);

    if ($resultadoPerguntas->num_rows > 0) {
        while ($pergunta = $resultadoPerguntas->fetch_assoc()) {
            echo "<div class='card {$pergunta['NomeCategoria']}'>";
            echo "<h2>{$pergunta['NomeCategoria']}</h2>";
            echo "<p>{$pergunta['PerguntaTexto']}</p>";
            echo "<p>{$pergunta['RespostaTexto']}</p>";
            echo "</div>";
        }
    } else {
        echo "Nenhuma pergunta encontrada para: $query";
    }

    // Fecha a conexão com o banco de dados
    $conexao->close();
} else {
    // Se 'q' não estiver presente, exiba uma mensagem padrão
    echo "Digite algo na barra de pesquisa.";
}
?>
