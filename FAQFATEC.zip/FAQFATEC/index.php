<?php
// Conectar ao banco de dados (substitua as credenciais conforme necessário)
$conexao = new mysqli("localhost", "root", "", "faqfatec");

// Verificar a conexão
if ($conexao->connect_error) {
    die("Falha na conexão: " . $conexao->connect_error);
}

// Iniciar a sessão
session_start();

// Autenticação
$usuarioLogado = isset($_SESSION['aluno_id']);

// Lógica de busca
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['q'])) {
    $termoBusca = $conexao->real_escape_string($_GET['q']);

    // Query SQL para buscar perguntas relacionadas ao termo de busca
    $queryBusca = "SELECT Categorias.NomeCategoria, Perguntas.PerguntaTexto, Respostas.RespostaTexto
                   FROM Perguntas
                   INNER JOIN Categorias ON Perguntas.CategoriaID = Categorias.CategoriaID
                   INNER JOIN Respostas ON Perguntas.PerguntaID = Respostas.PerguntaID
                   WHERE Perguntas.status = 'respondida' AND (Perguntas.PerguntaTexto LIKE '%$termoBusca%' OR Respostas.RespostaTexto LIKE '%$termoBusca%')
                   ORDER BY Perguntas.dataCriacao DESC";

    $resultadoBusca = $conexao->query($queryBusca);
} else {
    // Lógica padrão de exibição de cards quando não há busca
    $query = "SELECT Categorias.NomeCategoria, Perguntas.PerguntaTexto, Respostas.RespostaTexto
              FROM Perguntas
              INNER JOIN Categorias ON Perguntas.CategoriaID = Categorias.CategoriaID
              INNER JOIN Respostas ON Perguntas.PerguntaID = Respostas.PerguntaID
              WHERE Perguntas.status = 'respondida'
              ORDER BY Perguntas.dataCriacao DESC";

    $resultadoBusca = $conexao->query($query);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" />
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/responsividade.css">
    <meta charset="UTF-8">
    <title>FAQ Fatec</title>
</head>
<body>
    <div class="topo">
        <img class="fatecimg" src="img/logo.png">
        <h1>Seja Bem Vindo A FAQ - Tire Aqui Sua Dúvida !!!</h1>

        <?php
        // Se o usuário estiver logado, exibir informações e opções do usuário
        if ($usuarioLogado) {
            $consulta = $conexao->prepare('SELECT email, RA, Nome, imagem_path FROM alunos WHERE AlunoID = ?');
            $consulta->bind_param('i', $_SESSION['aluno_id']);
            $consulta->execute();
            $aluno = $consulta->get_result()->fetch_assoc();
            $consulta->close();

            echo '<div class="navbar right-sidebar">';
            echo '<div class="sidebar-content">';
            echo '<div class="welcome-msg">Bem-vindo, ' . htmlspecialchars($aluno['Nome']) . '!</div>';
            echo '<div id="adminInfoContainer" class="info-list">';
            echo '<img src="' . htmlspecialchars($aluno['imagem_path']) . '" alt="Imagem" id="adminImage">';
            echo '<ul id="userItems" class="user-items">';
            echo '<li>RA: ' . htmlspecialchars($aluno['RA']) . '</li>';
            echo '<li>Nome: ' . htmlspecialchars($aluno['Nome']) . '</li>';
            echo '<li>Email: ' . htmlspecialchars($aluno['email']) . '</li>';
            echo '<li><a href="editar_perfil.php">Editar Perfil</a></li>';
            echo '<li><a href="logout.php">Sair</a></li>';
            echo '</ul>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        } else {
            // Se não estiver logado, exibir formulário de login e opções de usuário
            echo '<div class="cadastro">';
            echo '<form class="login" action="teste.php">';
            echo '<button type="submit">Usuário</button>';
            echo '</form>';
            echo '<form class="login" action="aluno/logininicio.php">';
            echo '<button type="submit">Login</button>';
            echo '</form>';
            echo '<form class="login" action="admin/login.php">';
            echo '<button type="submit">Administrador</button>';
            echo '</form>';
            echo '</div>';
        }
        ?>

    </div>
    <!-- Barra de navegação -->
    <div class='navbars'>
        <ul id="categorias-list">
            <?php
            // Exibir as categorias na barra de navegação
            $queryCategorias = "SELECT DISTINCT NomeCategoria FROM Categorias";
            $resultadoCategorias = $conexao->query($queryCategorias);

            while ($categoria = $resultadoCategorias->fetch_assoc()) {
                echo "<li><a href='?q={$categoria['NomeCategoria']}' data-categoria='{$categoria['NomeCategoria']}'>{$categoria['NomeCategoria']}</a></li>";
            }
            ?>
        </ul>

        <!-- Barra de pesquisa -->
        <div class="search-bar">
            <form action="" method="get">
                <input type="text" name="q" placeholder="Pesquisar...">
                <button type="submit">Buscar</button>
            </form>
        </div>
    </div>

    <img class="gif" src="img/education-students.gif">
    <div class="card-container">
        <?php
        // Exibir os resultados da busca ou os cards padrão
        while ($row = $resultadoBusca->fetch_assoc()) {
            echo "<div id='{$row['NomeCategoria']}' class='card {$row['NomeCategoria']}'>";
            echo "<h2>{$row['NomeCategoria']}</h2>";
            echo "<p>{$row['PerguntaTexto']}</p>";
            echo "<p>{$row['RespostaTexto']}</p>";
            echo "</div>";
        }
        ?>

        <div id="assistant-container" onclick="toggleChatBox()">
            <i class="fas fa-comments"></i>
            <div id="help-message"></div>
        </div>

        <div id="chat-box">
            <div id="chat-content"></div>
            <input type="text" id="user-input" placeholder="Digite sua pergunta...">
        </div>
    </div>

    <footer>
        <?php
        // Exibir formulário de pergunta se o usuário estiver logado
        if ($usuarioLogado) {
            echo '<div id="user-question-form-container" class="footer-section">';
            echo '<div id="user-question-form" class="footer-content" style="text-align: left; display: none;">';
            echo '<h3>Faça uma pergunta:</h3>';
            echo '<form method="post" action="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '">';
            echo '<textarea name="pergunta" rows="4" cols="50" required></textarea><br>';
            echo '<button type="submit">Enviar Pergunta</button>';
            echo '</form>';
            echo '</div>';
            echo '<button id="show-form-button">Exibir Formulário</button>';
            echo '</div>';
        } else {
            // Se não estiver logado, exibir mensagem indicando a necessidade de login
            echo '<div id="not-logged-in-message-container" class="footer-section">';
            echo '<div class="not-logged-in-message" style="color: white; text-align: center;">Você precisa estar logado para fazer uma pergunta. Faça o <a href="logininicio.php">login</a> ou <a href="cadastro.php">cadastro</a> para continuar. Se preferir, pode retirar sua dúvida com o nosso Chat Ao Lado.</div>';
            echo '</div>';
        }
        ?>

        <div id="footer-content" class="flex-container footer-section">
            <div id="contact-info" class="footer-content">
                <h3>Faça aqui sua Pergunta!!!</h3>
                <p>Email: contato@exemplo.com</p>
                <p>Telefone: (XX) XXXX-XXXX</p>
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Adicionar um ouvinte de eventos para lidar com a seleção de categoria
            var categoriasList = document.getElementById('categorias-list');
            categoriasList.addEventListener('click', function(event) {
                var categoriaSelecionada = event.target.getAttribute('data-categoria');

                // Verificar se a categoria foi selecionada
                if (categoriaSelecionada) {
                    // Chamar a função para carregar perguntas relacionadas à categoria selecionada
                    carregarPerguntasPorCategoria(categoriaSelecionada);
                }
            });

            // Função para carregar perguntas relacionadas à categoria
            function carregarPerguntasPorCategoria(categoria) {
                // Realizar uma requisição AJAX para buscar perguntas relacionadas à categoria
                var xhr = new XMLHttpRequest();
                xhr.open('GET', '?q=' + categoria, true);

                xhr.onreadystatechange = function() {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        // Atualizar dinamicamente os resultados na página
                        var cardContainer = document.querySelector('.card-container');
                        cardContainer.innerHTML = xhr.responseText;
                    }
                };

                xhr.send();
            }
        });
    </script>

    <script src="js/script.js"></script>
</body>
</html>

<?php
// Fechar a conexão no final do arquivo
$conexao->close();
?>
