<!DOCTYPE html>
<html lang="pt-br">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" />
<link rel="stylesheet" href="css/index.css">
<link rel="stylesheet" href="css/responsividade.css">
<meta charset="UTF-8">
<title>FAQ Fatec</title>

</head>
</script>
</head>
<body>
<div class="topo">
        <img class ="fatecimg" src="img/logo.png">
        <h1>Seja Bem Vindo A FAQ - Tire Aqui Sua Dúvida !!!</h1>

<?php
session_start();

// Conectar ao banco de dados (substitua as credenciais conforme necessário)
$conexao = new mysqli("localhost", "root", "", "faqfatec");

// Verificar a conexão
if ($conexao->connect_error) {
    die("Falha na conexão: " . $conexao->connect_error);
}

// Autenticação
$usuarioLogado = false;

if (isset($_SESSION['aluno_id'])) {
    $usuarioLogado = true;
}

// Processar o envio do formulário de perguntas
if ($_SERVER["REQUEST_METHOD"] == "POST" && $usuarioLogado) {
    $perguntaTexto = $_POST['pergunta'];

    // Validar e inserir a pergunta no banco de dados
    if (!empty($perguntaTexto)) {
        $categoriaID = 1; // Defina a categoria desejada para as perguntas do usuário
        $alunoID = $_SESSION['aluno_id'];

        // Inserir a pergunta no banco de dados com perguntaid configurado como AUTO_INCREMENT
        $stmt = $conexao->prepare('INSERT INTO perguntas (CategoriaID, AlunoID, PerguntaTexto, status) VALUES (?, ?, ?, "pendente")');
        $stmt->bind_param('iis', $categoriaID, $alunoID, $perguntaTexto);
        $stmt->execute();

        // Obter o ID da pergunta recém-inserida
        $perguntaID = $conexao->insert_id;

        // Verificar se a preparação foi bem-sucedida
        if ($stmt === false) {
            die('Erro na preparação da instrução SQL: ' . $conexao->error);
        }

        $stmt->close();

        // Agora, você pode usar $perguntaID para inserir na tabela de respostas
        // Neste exemplo, a resposta será sempre vazia
        $respostaTexto = '';

        // Substitua 'sua_tabela_de_respostas' pelo nome correto da tabela de respostas
        $stmtResposta = $conexao->prepare('INSERT INTO respostas (PerguntaID, RespostaTexto) VALUES (?, ?)');
        $stmtResposta->bind_param('is', $perguntaID, $respostaTexto);
        $stmtResposta->execute();

        // Verificar se a preparação foi bem-sucedida
        if ($stmtResposta === false) {
            die('Erro na preparação da instrução SQL para respostas: ' . $conexao->error);
        }

        $stmtResposta->close();

        echo '<div style="color: green; text-align: center; margin-top: 10px;">Pergunta e resposta enviadas com sucesso!</div>';
    } else {
        echo '<div style="color: red; text-align: center; margin-top: 10px;">Por favor, preencha a pergunta antes de enviar.</div>';
    }
}
if (isset($_SESSION['aluno_id'])) {
    // Usuário autenticado, exibir mensagem de boas-vindas e botão de logout
    $conn = new mysqli('localhost', 'root', '', 'faqfatec');

    if ($conn->connect_error) {
        die("Conexão falhou: " . $conn->connect_error);
    }

// Consultar o banco de dados para obter informações do aluno, incluindo a imagem
$consulta = $conn->prepare('SELECT email, RA, Nome, imagem_path FROM alunos WHERE AlunoID = ?');
$consulta->bind_param('i', $_SESSION['aluno_id']);  // 'i' representa o tipo de dado (inteiro)
$consulta->execute();
$resultado = $consulta->get_result();
$aluno = $resultado->fetch_assoc();


// Fechar a conexão
$consulta->close();
$conn->close();
} else {
    // Exibir formulário de login e botões de administrador
    echo '<div class="cadastro">';
    echo '<form class="login" action=teste.php">';
    echo '<button type="submit">Usuário</button>';
    echo '</form>';
    echo '<form class="login" action="aluno/logininicio.php">';
    echo '<button type="submit">Login</button>';
    echo '</form>';
    echo '<form class="login" action="admin/login.php">';
    echo '<button type="submit">Administrador</button>';
    echo '</form>';
    echo '</div>';
}
?>        
<?php
if ($usuarioLogado) {
    echo '<div class="navbar right-sidebar">';
    echo '<div class="sidebar-content">';
    echo '<div class="welcome-msg">Bem-vindo, ' . htmlspecialchars($aluno['Nome']) . '!</div>';
    echo '<div id="adminInfoContainer" class="info-list">';  // Adicione a classe info-list aqui
    echo '<img src="' . htmlspecialchars($aluno['imagem_path']) . '" alt="Imagem" id="adminImage">';

    // Lista oculta inicialmente
    echo '<ul id="userItems" class="user-items">';
    echo '<li>RA: ' . htmlspecialchars($aluno['RA']) . '</li>';
    echo '<li>Nome: ' . htmlspecialchars($aluno['Nome']) . '</li>';
    echo '<li>Email: ' . htmlspecialchars($aluno['email']) . '</li>';
    echo '<li><a href="editar_perfil.php">Editar Perfil</a></li>';
    echo '<li><a href="logout.php">Sair</a></li>';
    echo '</ul>';

    echo '</div>';
    echo '</div>';
    echo '</div>';
}
?>



        </div>

        <img class="gif" src="img/education-students.gif">

        <?php
// Conectar ao banco de dados (substitua as credenciais conforme necessário)
$conexao = new mysqli("localhost", "root", "", "faqfatec");

// Verificar a conexão
if ($conexao->connect_error) {
    die("Falha na conexão: " . $conexao->connect_error);
}

// Consultar o banco de dados para obter perguntas, respostas e categorias
$query = "SELECT Categorias.NomeCategoria, Perguntas.PerguntaTexto, Respostas.RespostaTexto
          FROM Perguntas
          INNER JOIN Categorias ON Perguntas.CategoriaID = Categorias.CategoriaID
          INNER JOIN Respostas ON Perguntas.PerguntaID = Respostas.PerguntaID
          WHERE Perguntas.status = 'respondida'
          ORDER BY Perguntas.dataCriacao DESC";

$resultado = $conexao->query($query);

// Exibir as informações em cards
echo "<div class='card-container'>";

// Loop para exibir as informações em cards
$cardsExibidos = 0;

while ($row = $resultado->fetch_assoc()) {
    if ($cardsExibidos < 8) {
        echo "<div class='card'>";
        echo "<h2>{$row['NomeCategoria']}</h2>";
        echo "<p>{$row['PerguntaTexto']}</p>";
        echo "<p>{$row['RespostaTexto']}</p>";
        echo "</div>";

        $cardsExibidos++;
    } else {
        break; // Interrompe o loop após exibir 8 cartões
    }
}
?>




<div id="assistant-container" onclick="toggleChatBox()">
    <i class="fas fa-comments"></i>
    <div id="help-message"></div>
</div>

<div id="chat-box">
    <div id="chat-content"></div>
    <input type="text" id="user-input" placeholder="Digite sua pergunta...">
</div>
<footer>
<?php
    if ($usuarioLogado) {
        echo '<div id="user-question-form-container" class="footer-section">';
        echo '<div id="user-question-form" class="footer-content" style="text-align: left; display: none;">';
        echo '<h3>Faça uma pergunta:</h3>';
        echo '<form method="post" action="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '">';
        echo '<textarea name="pergunta" rows="4" cols="50" required></textarea><br>';
        echo '<button type="submit">Enviar Pergunta</button>';
        echo '</form>';
        echo '</div>';
        echo '<button id="show-form-button">Exibir Formulário</button>';
        echo '</div>';
    } else {
        echo '<div id="not-logged-in-message-container" class="footer-section">';
        echo '<div class="not-logged-in-message" style="color: white; text-align: center;">Você precisa estar logado para fazer uma pergunta. Faça o <a href="logininicio.php">login</a> ou <a href="cadastro.php">cadastro</a> para continuar. Se preferir, pode retirar sua dúvida com o nosso Chat Ao Lado.</div>';
        echo '</div>';
    }
?>

    <div id="footer-content" class="flex-container footer-section">
        <div id="contact-info" class="footer-content">
            <!-- Adicione suas informações de contato aqui -->
            <p>Email: contato@exemplo.com</p>
            <p>Telefone: (XX) XXXX-XXXX</p>
        </div>
    </div>

</footer>
<script>
    // Adicione um script JavaScript para mostrar/ocultar a lista ao clicar na imagem
    const adminImage = document.getElementById('adminImage');
    const infoList = document.querySelector('.user-items');

    adminImage.addEventListener('click', function() {
        // Alternar a visibilidade da lista
        infoList.style.display = infoList.style.display === 'none' ? 'block' : 'none';
    });
</script>
<script src="js/script.js"></script>
</body>
</body>
</html>