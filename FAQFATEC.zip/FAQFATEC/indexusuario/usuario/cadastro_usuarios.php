<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Usuario</title>
    <link rel="stylesheet" href="css/formulario.css">
</head>
<body>

<?php
// Verificar se o usuário já está logado
if (isset($_SESSION['aluno_id'])) {
    echo '<h2>Bem-vindo, Usuario!</h2>';
    echo '<p><a href="logout.php" class="button">Logout</a></p>';
} else {
    // Exibir formulário de cadastro
    echo '<form method="post" action="cadastrarbd.php">';
    echo '<h2>Cadastro</h2>';
    echo '<label for=email">E-MAIL:</label>';
    echo '<input type="email" id="email" name="email" required>';
    echo '<label for="nome">Nome:</label>';
    echo '<input type="text" id="nome" name="nome" required>';
    echo '<label for="senha">Senha:</label>';
    echo '<input type="password" id="senha" name="senha" required>';
    echo '<input type="submit" value="Cadastrar" class="button">';
    echo '<p><a href="index.php" class="button">Voltar</a></p>';
    echo '</form>';
}
?>


</body>
</html>
