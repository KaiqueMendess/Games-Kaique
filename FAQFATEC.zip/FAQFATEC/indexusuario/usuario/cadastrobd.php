<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $nome = $_POST['nome'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);

    // Conexão com o banco de dados
    $conn = new mysqli('localhost', 'root', '', 'faqfatec');

    if ($conn->connect_error) {
        die("Conexão falhou: " . $conn->connect_error);
    }

    // Inserir novo aluno
    $inserir = $conn->prepare('INSERT INTO usuario (email, Nome, Senha) VALUES (?, ?, ?)');
    $inserir->bind_param('sss', $ra, $nome, $senha);  // 'sss' representa os tipos de dados (string, string, string)
    $inserir->execute();

    echo '<p>Usuario cadastrado com sucesso!</p>';
    echo '<p><a href="index.php" class="button">Continuar</a></p>';    

    // Fechar a conexão
    $inserir->close();
    $conn->close();
}
?>
