<?php
// Verifique se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conectar ao banco de dados
    $conn = new mysqli("localhost", "root", "", "faqfatec");

    // Verificar a conexão
    if ($conn->connect_error) {
        die("Conexão falhou: " . $conn->connect_error);
    }

    // Capturar dados do formulário
    $cpf = $_POST["cpf"];
    $nome = $_POST["nome"];
    $senha = password_hash($_POST["senha"], PASSWORD_DEFAULT);

    // Inserir dados no banco de dados
    $sql = "INSERT INTO administradores (cpf, nome, senha) VALUES ('$cpf', '$nome', '$senha')";

    if ($conn->query($sql) === TRUE) {
        echo "<p>Cadastro realizado com sucesso!</p>";
        echo '<a href="login.php"><button>Login</button></a>';
    } else {
        echo "Erro ao cadastrar: " . $conn->error;
    }

    // Fechar a conexão
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Administrador</title>
</head>
<body>
    <h2>Cadastro de Administrador</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="cpf">CPF:</label>
        <input type="text" name="cpf" required><br>

        <label for="nome">Nome:</label>
        <input type="text" name="nome" required><br>

        <label for="senha">Senha:</label>
        <input type="password" name="senha" required><br>

        <input type="submit" value="Cadastrar">
        <p>Ja possui cadastro?</p>
        <a href="login.php">Faça login!!!</p>
    </form>
</body>
</html>
