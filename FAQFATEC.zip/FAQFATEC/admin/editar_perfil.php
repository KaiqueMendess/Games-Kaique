<?php
// Conectar ao banco de dados
$conn = new mysqli("localhost", "root", "", "faqfatec");

// Verificar a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lógica para atualizar o perfil aqui
    // ...

    // Atualizar nome, e-mail, senha e imagem
    $novoNome = isset($_POST["novo_nome"]) ? $_POST["novo_nome"] : '';
    $novoEmail = isset($_POST["novo_email"]) ? $_POST["novo_email"] : '';
    $novaSenha = isset($_POST["nova_senha"]) ? $_POST["nova_senha"] : '';

    // Substituir a imagem
    if ($_FILES["nova_imagem"]["name"]) {
        // Lógica para processar o upload da nova imagem
        $nomeArquivo = basename($_FILES['nova_imagem']['name']);
        $caminhoArquivo = 'http://localhost/FAQFATEC/admin/adminimg/' . $nomeArquivo;

        if (move_uploaded_file($_FILES['nova_imagem']['tmp_name'], $caminhoArquivo)) {
            // Atualizar o caminho da nova imagem no banco de dados
            $novoCaminhoImagem = $caminhoArquivo;
            $sqlUpdateImagem = "UPDATE administradores SET imagem_path = ? WHERE id = ?";
            $stmtUpdateImagem = $conn->prepare($sqlUpdateImagem);

            if ($stmtUpdateImagem) {
                // Binds dos parâmetros
                $stmtUpdateImagem->bind_param("si", $novoCaminhoImagem, $adminID);

                // Suponha que você tenha o ID do administrador armazenado em algum lugar, substitua pela lógica real
                $adminID = 1;

                // Executar a atualização
                if ($stmtUpdateImagem->execute()) {
                    echo "Imagem enviada e caminho atualizado no banco de dados com sucesso.";
                } else {
                    echo "Erro ao atualizar o caminho da imagem no banco de dados: " . $stmtUpdateImagem->error;
                }

                $stmtUpdateImagem->close();
            } else {
                echo "Erro na preparação da consulta: " . $conn->error;
            }
        } else {
            echo "Erro ao fazer upload da imagem.";
            exit();
        }
    }

    // Restante da lógica de atualização
    // ...

    // Redirecionar de volta para o painel_admin.php após a atualização
    header("Location: painel_admin.php");
    exit();
}

// Consultar informações do administrador
$sqlSelectAdmin = "SELECT * FROM administradores WHERE id = ?";
$stmtSelectAdmin = $conn->prepare($sqlSelectAdmin);

if ($stmtSelectAdmin) {
    $stmtSelectAdmin->bind_param("i", $adminID);

    // Suponha que você tenha o ID do administrador armazenado em algum lugar, substitua pela lógica real
    $adminID = 1;

    if ($stmtSelectAdmin->execute()) {
        $resultAdmin = $stmtSelectAdmin->get_result();

        if ($resultAdmin) {
            $administrador = $resultAdmin->fetch_assoc();
        } else {
            echo "Erro na obtenção do resultado: " . $stmtSelectAdmin->error;
        }
    } else {
        echo "Erro na execução da consulta: " . $stmtSelectAdmin->error;
    }

    $stmtSelectAdmin->close();
} else {
    echo "Erro na preparação da consulta: " . $conn->error;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Perfil</title>
    <style>
        body {
            background-image: url('../img/fundoadmin.jpg');
            background-size: 100%;
            font-family: Arial, sans-serif; /* Escolha uma fonte apropriada */
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        #content {
            text-align: center;
            background-color: rgba(255, 255, 255, 0.8); /* Adicione um fundo branco translúcido */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3); /* Adicione uma sombra leve */
        }

        h2 {
            color: #333; /* Cor do texto */
            background-color: #eee; /* Cor de fundo */
            padding: 10px; /* Espaçamento interno */
            border-radius: 5px;
        }

        img {
            width: 100px; /* Ajuste o tamanho conforme necessário */
            height: auto; /* Isso mantém a proporção da imagem */
            border-radius: 50%;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        label {
            margin-bottom: 5px;
        }

        input {
            margin-bottom: 10px;
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            width: 100%;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #e50914; /* Cor de fundo do botão */
            color: #fff; /* Cor do texto no botão */
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div id="content">
        <h2>Editar Perfil</h2>

        <!-- Exibição da imagem -->
        <img src="<?php echo $administrador['imagem_path'] ?>" alt="Imagem do Perfil">

        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
            <label for="novo_nome">Novo Nome:</label>
            <input type="text" name="novo_nome" value="<?php echo $administrador['nome']; ?>">

            <label for="nova_senha">Nova Senha:</label>
            <input type="password" name="nova_senha">

            <label for="nova_imagem">Nova Imagem:</label>
            <input type="file" name="nova_imagem">

            <input type="submit" value="Salvar">
        </form>
    </div>
</body>
</html>

