<?php
// Verifique se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conectar ao banco de dados
    $conn = new mysqli("localhost", "root", "", "faqfatec");

    // Verificar a conexão
    if ($conn->connect_error) {
        die("Conexão falhou: " . $conn->connect_error);
    }

    // Capturar dados do formulário
    $cpf = $_POST["cpf"];
    $senha = $_POST["senha"];

    // Consultar o banco de dados para verificar as credenciais
    $sql = "SELECT * FROM administradores WHERE cpf='$cpf'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($senha, $row["senha"])) {
            header("Location: painel_admin.php");
        } else {
            echo "Senha incorreta.";
        }
    } else {
        echo "Usuário não encontrado.";
    }

    // Fechar a conexão
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login de Administrador</title>
    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            background-image: linear-gradient(to bottom, rgba(0, 0, 0, 0.0900), rgba(0, 0, 0, 0.090)), linear-gradient(to top, rgba(0, 0, 0, 0.432), rgba(0, 0, 0, 0.007)), url('../img/fundoadmin.jpg');
            background-position: center;
            background-size: cover;
            background-repeat: no-repeat;
        }

        form {
            background-color: #111;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            max-width: 25%;
            width: 100%;
            text-align: center;
            color: #fff;
        }

        label {
            display: block;
            margin: 10px 0;
        }

        input {
            width: calc(100% - 10px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #555;
            border-radius: 4px;
            background-color: #333;
            color: #fff;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #ff000d;
            color: #fff;
            cursor: pointer;
        }

        a {
            color: #ffffff;
            text-decoration: none;
        }

        h4 {
            background-color: #ff0000;
            color: #fff;
            cursor: pointer;
            border-radius: 4px;
            padding: 15px;
            margin-bottom: 20px;
        }

        a:hover {
            text-decoration: underline;
        }

        p {
            background-color: #ff000d; /* Cor do botão semelhante à Netflix */
            color: #fff;
            cursor: pointer;
            padding: 5px;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <h2>Login de Administrador</h2>    
        <label for="cpf">CPF:</label>
        <input type="text" name="cpf" required><br>

        <label for="senha">Senha:</label>
        <input type="password" name="senha" required><br>

        <input type="submit" value="Entrar">
        <p><a href="../index.php">Sair</a></p>

    </form>
</body>
</html>

