<?php
// Conectar ao banco de dados
$conn = new mysqli("localhost", "root", "", "faqfatec");

// Verificar a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Consultar informações do administrador
$sqlSelectAdmin = "SELECT * FROM administradores WHERE id = ?";
$stmtSelectAdmin = $conn->prepare($sqlSelectAdmin);

if ($stmtSelectAdmin) {
    $stmtSelectAdmin->bind_param("i", $adminID);

    // Suponha que você tenha o ID do administrador armazenado em algum lugar, substitua pela lógica real
    $adminID = 1;

    if ($stmtSelectAdmin->execute()) {
        $resultAdmin = $stmtSelectAdmin->get_result();

        if ($resultAdmin) {
            $administrador = $resultAdmin->fetch_assoc();
        } else {
            echo "Erro na obtenção do resultado: " . $stmtSelectAdmin->error;
        }
    } else {
        echo "Erro na execução da consulta: " . $stmtSelectAdmin->error;
    }

    $stmtSelectAdmin->close();
} else {
    echo "Erro na preparação da consulta: " . $conn->error;
}

// Consultar perguntas, respostas e seus status
$query = "SELECT Categorias.NomeCategoria, Perguntas.PerguntaID, Perguntas.PerguntaTexto, Respostas.RespostaTexto, Perguntas.status
          FROM Perguntas
          INNER JOIN Categorias ON Perguntas.CategoriaID = Categorias.CategoriaID
          LEFT JOIN Respostas ON Perguntas.PerguntaID = Respostas.PerguntaID
          ORDER BY Perguntas.status = 'pendente' DESC, Perguntas.dataCriacao DESC";
$resultado = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perguntas e Respostas</title>
    <style>
        /* Adicione estilos para posicionar a imagem à esquerda e ajustar o tamanho */
        #adminInfoContainer {
            display: flex;
            align-items: center;
        }

        #adminImage {
            width: 50px; /* Ajuste o tamanho conforme necessário */
            height: auto; /* Isso mantém a proporção da imagem */
            margin-right: 10px; /* Adiciona um espaçamento à direita da imagem */
            border-radius: 20%;
        }
 

        /* Adicione um estilo para ocultar a lista inicialmente */
        .info-list {
            display: none;
            list-style-type: none;
            padding: 0;
            background-color: #333; /* Cor de fundo roxo */
            color: #fff; /* Cor do texto branco */
            font-weight: bold; /* Fonte em negrito */
            padding: 5px 10px;
            margin-bottom: 5px;
        }
        .info-list a {
          color: white;
        }
    
        body{
            background-image:url('../img/fundoadmin.jpg');
            background-size: 100%;
            
        }

        h2 {
        color: #fff; /* Cor do texto */
        background-color: #333; /* Cor de fundo */
        padding: 10px; /* Espaçamento interno */
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    th, td {
        border: 1px solid #ddd; /* Borda */
        padding: 8px; /* Espaçamento interno */
        text-align: left; /* Alinhamento do texto */
    }

    th {
        background-color: #555; /* Cor de fundo do cabeçalho */
        color: #fff; /* Cor do texto no cabeçalho */
    }

    tr { 
        background-color: #f2f2f2;
    }


    /* Estilos para o botão "Editar" */
    .edit-button { 
        background-color: #e50914; /* Cor de fundo do botão */
        color: #fff; /* Cor do texto no botão */
        padding: 8px 15px; /* Espaçamento interno do botão */
        text-decoration: none; /* Remover sublinhado do link */
        border-radius: 5px; /* Borda arredondada */
        display: inline-block; /* Tornar o link um bloco */
        margin-right: 5px; /* Espaçamento à direita do botão */
    }
    .delete-button { 
        background-color: #e50914; /* Cor de fundo do botão */
        color: #fff; /* Cor do texto no botão */
        padding: 8px 15px; /* Espaçamento interno do botão */
        text-decoration: none; /* Remover sublinhado do link */
        border-radius: 5px; /* Borda arredondada */
        display: inline-block; /* Tornar o link um bloco */
        margin-right: 5px; /* Espaçamento à direita do botão */
    }

    td.status-respondida {
    color: black; /* Cor verde para perguntas respondidas */
    background-color: green;
    font-style: bold;
}

td.status-pendente {
    color: black; /* Cor vermelha para perguntas pendentes */
    background-color: red;
    font-style: bold;
}

    </style>
</head>
<body>
    <!-- Adicione isso onde você exibe as informações do administrador no painel_admin.php -->
    <div id="adminInfoContainer">
        <img src="<?php echo htmlspecialchars($administrador['imagem_path']); ?>" alt="Imagem" id="adminImage">

        <!-- Lista oculta inicialmente -->
        <ul class="info-list">
            <li>Nome: <?php echo htmlspecialchars($administrador['nome']); ?></li>
            <li>CPF: <?php echo htmlspecialchars($administrador['cpf']); ?></li>
            <li><a href="editar_perfil.php">Editar Perfil</a></li>
            <li><a href="../index.php">Sair</a></li>
        </ul>
    </div>


    <!-- Adicione um link para editar o perfil -->

    <h2>Perguntas e Respostas</h2>

    <table border="1">
        <tr>
            <th>ID</th>
            <th>Pergunta</th>
            <th>Respostas</th>
            <th>Status</th>
            <th>Ação</th>
            <th>Excluir</th>

        </tr>
        <?php


// Exibir todas as perguntas ordenadas
foreach ($resultado as $row) {
    echo "<tr>";
    echo "<td>{$row['PerguntaID']}</td>";
    echo "<td>{$row['PerguntaTexto']}</td>";
    echo "<td>{$row['RespostaTexto']}</td>";
    echo "<td class='status-{$row['status']}'>{$row['status']}</td>";
    echo "<td><a href='editar_pergunta.php?id={$row['PerguntaID']}' class='edit-button'>Editar</a></td>";
    echo "<td><a href='excluir_pergunta.php?id={$row['PerguntaID']}' class='delete-button'>Excluir</a></td>";
    echo "</tr>";
}

// Fechar a conexão após exibir os resultados
$conn->close();
?>
    </table>
    <script>
        // Adicione um script JavaScript para mostrar/ocultar a lista ao clicar na imagem
        const adminImage = document.getElementById('adminImage');
        const infoList = document.querySelector('.info-list');

        adminImage.addEventListener('click', function() {
            // Alternar a visibilidade da lista
            infoList.style.display = infoList.style.display === 'none' ? 'block' : 'none';
        });
    </script>
</body>
</html>
