<?php
// Conectar ao banco de dados
$conn = new mysqli("localhost", "root", "", "faqfatec");

// Verificar a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Função para limpar dados de entrada
function limparEntrada($entrada) {
    return htmlspecialchars(stripslashes(trim($entrada)));
}

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capturar dados do formulário
    $categoriaID = isset($_POST["categoria"]) ? $_POST["categoria"] : null;
    $perguntaID = isset($_POST["pergunta_id"]) ? $_POST["pergunta_id"] : null;
    $perguntaTexto = limparEntrada(isset($_POST["pergunta_texto"]) ? $_POST["pergunta_texto"] : '');
    $respostaTexto = limparEntrada(isset($_POST["resposta_texto"]) ? $_POST["resposta_texto"] : '');
    $status = limparEntrada(isset($_POST["status"]) ? $_POST["status"] : '');

    // Verificar se os dados do formulário estão preenchidos
    if (empty($perguntaTexto) || empty($respostaTexto) || empty($status)) {
        echo "Por favor, preencha todos os campos.";
    } else {
        // Verificar se o ID da pergunta é válido
        if ($perguntaID !== null && is_numeric($perguntaID)) {
            // Atualizar dados no banco de dados
            $sqlUpdatePergunta = "UPDATE perguntas SET PerguntaTexto = ?, status = ?, CategoriaID = ? WHERE PerguntaID = ?";
            $sqlUpdateResposta = "UPDATE respostas SET RespostaTexto = ? WHERE PerguntaID = ?";

            $stmtUpdatePergunta = $conn->prepare($sqlUpdatePergunta);
            $stmtUpdateResposta = $conn->prepare($sqlUpdateResposta);

            if ($stmtUpdatePergunta && $stmtUpdateResposta) {
                // Binds dos parâmetros
                $stmtUpdatePergunta->bind_param("ssii", $perguntaTexto, $status, $categoriaID, $perguntaID);
                $stmtUpdateResposta->bind_param("si", $respostaTexto, $perguntaID);

                // Executar as atualizações
                $updatePergunta = $stmtUpdatePergunta->execute();
                $updateResposta = $stmtUpdateResposta->execute();

                if ($updatePergunta && $updateResposta) {
                    echo "Pergunta e resposta atualizadas com sucesso!";
                    
                    // Redirecionar para a página de administração após uma atualização bem-sucedida
                    header("Location: painel_admin.php");
                    exit();
                } else {
                    echo "Erro ao atualizar a pergunta e resposta: " . $conn->error;
                }

                $stmtUpdatePergunta->close();
                $stmtUpdateResposta->close();
            } else {
                echo "Erro na preparação da consulta: " . $conn->error;
            }
        } else {
            echo "ID da pergunta inválido.";
        }
    }
}

// Capturar o ID da pergunta a ser editada
$perguntaID = isset($_GET["id"]) ? $_GET["id"] : null;

// Consultar a pergunta a ser editada com sua resposta, status e categoria
$sqlSelect = "SELECT perguntas.PerguntaID, perguntas.PerguntaTexto, respostas.RespostaTexto, perguntas.status, perguntas.CategoriaID
              FROM perguntas
              LEFT JOIN respostas ON perguntas.PerguntaID = respostas.PerguntaID
              WHERE perguntas.PerguntaID = ?";
$stmt = $conn->prepare($sqlSelect);

if ($stmt) {
    $stmt->bind_param("i", $perguntaID);

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        if ($result) {
            $pergunta = $result->fetch_assoc();
        } else {
            echo "Erro na obtenção do resultado: " . $stmt->error;
        }
    } else {
        echo "Erro na execução da consulta: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Erro na preparação da consulta: " . $conn->error;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Pergunta</title>
</head>
<body>
    <h2>Editar Pergunta</h2>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <input type="hidden" name="pergunta_id" value="<?php echo isset($pergunta['PerguntaID']) ? $pergunta['PerguntaID'] : ''; ?>">

        <label for="pergunta_texto">Pergunta:</label>
        <textarea name="pergunta_texto" rows="4" cols="50"><?php echo isset($pergunta['PerguntaTexto']) ? $pergunta['PerguntaTexto'] : ''; ?></textarea><br>

        <label for="resposta_texto">Resposta:</label>
        <textarea name="resposta_texto" rows="4" cols="50"><?php echo isset($pergunta['RespostaTexto']) ? $pergunta['RespostaTexto'] : ''; ?></textarea><br>

        <label for="status">Status:</label>
        <select name="status">
            <option value="pendente" <?php echo (isset($pergunta['status']) && $pergunta['status'] === 'pendente') ? 'selected' : ''; ?>>Pendente</option>
            <option value="respondida" <?php echo (isset($pergunta['status']) && $pergunta['status'] === 'respondida') ? 'selected' : ''; ?>>Respondida</option>
        </select><br>

        <label for="categoria">Categoria:</label>
        <select name="categoria">
            <?php
            // Consultar todas as categorias disponíveis
            $sqlCategorias = "SELECT CategoriaID, NomeCategoria FROM categorias";
            $resultCategorias = $conn->query($sqlCategorias);

            if ($resultCategorias->num_rows > 0) {
                while ($rowCategoria = $resultCategorias->fetch_assoc()) {
                    $categoriaID = $rowCategoria['CategoriaID'];
                    $nomeCategoria = $rowCategoria['NomeCategoria'];

                    // Verificar se é a categoria atual da pergunta
                    $selecionada = isset($pergunta['CategoriaID']) && $pergunta['CategoriaID'] == $categoriaID ? 'selected' : '';

                    echo "<option value=\"$categoriaID\" $selecionada>$nomeCategoria</option>";
                }
            }
            ?>
        </select><br>

        <input type="submit" value="Salvar">
    </form>
</body>
</html>
