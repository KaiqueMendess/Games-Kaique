-- Criação da tabela 'alunos'
CREATE TABLE alunos (
    AlunoID INT PRIMARY KEY AUTO_INCREMENT,
    Nome VARCHAR(50) NOT NULL,
    RA VARCHAR(10) NOT NULL,
    Senha VARCHAR(255) NOT NULL
);

-- Inserção de um aluno de exemplo
INSERT INTO alunos (Nome, RA, Senha) VALUES ('NomeDoAluno', 'RA12345', 'senha123');

-- Criação da tabela 'sessoes'
CREATE TABLE sessoes (
    SessaoID INT PRIMARY KEY AUTO_INCREMENT,
    AlunoID INT,
    FOREIGN KEY (AlunoID) REFERENCES alunos(AlunoID)
);

-- Exemplo de uma sessão válida
INSERT INTO sessoes (AlunoID) VALUES (1);
