<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Login</title>
    <link rel="stylesheet" href="../css/formulario.css">
</head>
<body>

<?php
session_start();

// Inicializa a mensagem de erro como vazia
$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ra = $_POST['ra'];
    $senha = $_POST['senha'];

    // Conexão com o banco de dados
    $conn = new mysqli('localhost', 'root', '', 'faqfatec');

    if ($conn->connect_error) {
        die("Conexão falhou: " . $conn->connect_error);
    }

    // Consultar o banco de dados para verificar as credenciais
    $consulta = $conn->prepare('SELECT AlunoID, Nome, Senha FROM alunos WHERE RA = ?');
    $consulta->bind_param('s', $ra);  // 's' representa o tipo de dado (string)
    $consulta->execute();
    $resultado = $consulta->get_result();

    if ($resultado->num_rows > 0) {
        $aluno = $resultado->fetch_assoc();

        // Verificar a senha
        if (password_verify($senha, $aluno['Senha'])) {
            // Credenciais válidas, armazenar o ID do aluno na sessão
            $_SESSION['aluno_id'] = $aluno['AlunoID'];

            // Redirecionar para a página de boas-vindas (index.php)
            header('Location: ../index.php');
            exit();
        } else {
            // Senha incorreta, definir a mensagem de erro
            $erro = 'Credenciais inválidas. Tente novamente.';
        }
    } else {
        // RA não encontrado, definir a mensagem de erro
        $erro = 'Credenciais inválidas. Tente novamente.';
    }

    // Fechar a conexão
    $consulta->close();
    $conn->close();
}

// Exibir formulário de login
echo '<form method="post" action="logininicio.php">';
echo '<h2>Login</h2>';

// Exibir a mensagem de erro acima do formulário, se houver
if (!empty($erro)) {
    echo '<p style="color: white; background-color: red;">' . $erro . '</p>';
}

echo '<label for="ra">RA:</label>';
echo '<input type="text" id="ra" name="ra" required>';
echo '<label for="senha">Senha:</label>';
echo '<input type="password" id="senha" name="senha" required>';
echo '<input type="submit" value="Login">';
echo '<p><a href="cadastro.php">Cadastrar</a></p>';
echo '<p><a href="../index.php">Sair</a></p>';
echo '</form>';
?>
