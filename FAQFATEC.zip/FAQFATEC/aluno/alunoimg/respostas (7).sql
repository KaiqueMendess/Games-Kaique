-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 07-Dez-2023 às 22:39
-- Versão do servidor: 10.4.28-MariaDB
-- versão do PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `faqfatec`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `respostas`
--

CREATE TABLE `respostas` (
  `PerguntaID` int(11) NOT NULL,
  `RespostaID` int(11) NOT NULL,
  `RespostaTexto` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `respostas`
--

INSERT INTO `respostas` (`PerguntaID`, `RespostaID`, `RespostaTexto`) VALUES
(1, 1, 'Você pode se matricular online no portal do aluno.'),
(2, 2, 'CPF ou documento contendo o número do CPF; foto 3X4 de rosto recente,fundo neutro; documento de quitação com o serviço militar para brasileiros maiores de 18 anos do sexo masculino; histórico escolar completo do Ensino Médio (frente e verso);'),
(3, 3, 'A grade curricular pode ser encontrada no site oficial da instituição.'),
(4, 4, 'Sim, oferecemos uma variedade de atividades extracurriculares, incluindo clubes e eventos.'),
(5, 5, 'Para obter informações sobre os cursos oferecidos pela FATEC, consulte o site oficial da instituição, onde geralmente você encontrará detalhes sobre cada curso, incluindo grade curricular, duração e objetivos.');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `respostas`
--
ALTER TABLE `respostas`
  ADD KEY `PerguntaID` (`PerguntaID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
