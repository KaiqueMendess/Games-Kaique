<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Aluno</title>
    <link rel="stylesheet" href="../css/formulario.css">
    <style>
        .message-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 20px; /* Ajuste a margem conforme necessário */
        }

        .error-message {
            color: white;
            margin-bottom: 10px; /* Ajuste a margem conforme necessário */
            padding: 10px; /* Adiciona espaço interno aos lados */
        }

        .message-container p {
            padding: 10px; /* Adiciona espaço interno aos lados */
        }
    </style>
</head>
<body>

<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ra = $_POST['ra'];
    $nome = $_POST['nome'];
    $email = $_POST['email']; // Adicionado campo de e-mail
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);

    // Conexão com o banco de dados
    $conn = new mysqli('localhost', 'root', '', 'faqfatec');

    if ($conn->connect_error) {
        die("Conexão falhou: " . $conn->connect_error);
    }

    // Verificar se já existe um aluno com o mesmo RA
    $verificar_ra = $conn->prepare('SELECT RA FROM alunos WHERE RA = ?');
    $verificar_ra->bind_param('s', $ra);
    $verificar_ra->execute();
    $verificar_ra->store_result();

    if ($verificar_ra->num_rows > 0) {
        echo '<div class="message-container">';
        echo '<p class="error-message">Já existe um aluno com esse RA!</p>';
        echo '<p><a href="cadastro.php" class="button">Voltar</a></p>';
        echo '</div>';
    } else {
        // Inserir novo aluno
        $inserir = $conn->prepare('INSERT INTO alunos (RA, Nome, Email, Senha) VALUES (?, ?, ?, ?)');
        $inserir->bind_param('ssss', $ra, $nome, $email, $senha);
        $inserir->execute();

        echo '<p>Aluno cadastrado com sucesso!</p>';
        echo '<br>';
        echo '<p><a href="../index.php" class="button">Continuar</a></p>';
    }

    // Fechar a conexão
    $verificar_ra->close();
    if (isset($inserir)) {
        $inserir->close();
    }
    $conn->close();
}
?>

</body>
</html>
