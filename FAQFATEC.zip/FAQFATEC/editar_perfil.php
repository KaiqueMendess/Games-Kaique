<?php
session_start();

// Conectar ao banco de dados
$conn = new mysqli("localhost", "root", "", "faqfatec");

// Verificar a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificar se o usuário está logado
if (isset($_SESSION['aluno_id'])) {
    $alunoID = $_SESSION['aluno_id'];
} else {
    // Se o usuário não estiver logado, redirecione para a página de login
    header("Location: index.php");
    exit();
}

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Atualizar nome, e-mail, senha e imagem
    $novoNome = isset($_POST["novo_nome"]) ? $_POST["novo_nome"] : '';
    $novaSenha = isset($_POST["nova_senha"]) ? $_POST["nova_senha"] : '';

    // Substituir a imagem
    if ($_FILES["nova_imagem"]["name"]) {
        // Lógica para processar o upload da nova imagem
        $nomeArquivo = basename($_FILES['nova_imagem']['name']);
        $caminhoArquivo = 'http://localhost/FAQFATEC/aluno/alunoimg/' . $nomeArquivo;

        if (move_uploaded_file($_FILES['nova_imagem']['tmp_name'], 'C:/xampp/htdocs/FAQFATEC/aluno/alunoimg/' . $nomeArquivo)) {
            // Atualizar o caminho da nova imagem no banco de dados
            $novoCaminhoImagem = $caminhoArquivo;
            $sqlUpdateImagem = "UPDATE alunos SET imagem_path = ? WHERE AlunoID = ?";
            $stmtUpdateImagem = $conn->prepare($sqlUpdateImagem);

            if ($stmtUpdateImagem) {
                // Binds dos parâmetros
                $stmtUpdateImagem->bind_param("si", $novoCaminhoImagem, $alunoID);

                // Executar a atualização
                if ($stmtUpdateImagem->execute()) {
                    echo "Imagem enviada e caminho atualizado no banco de dados com sucesso.";
                } else {
                    echo "Erro ao atualizar o caminho da imagem no banco de dados: " . $stmtUpdateImagem->error;
                }

                $stmtUpdateImagem->close();
            } else {
                echo "Erro na preparação da consulta: " . $conn->error;
            }
        } else {
            echo "Erro ao fazer upload da imagem.";
            exit();
        }
    }

    // Atualizar nome e senha
    $sqlUpdate = "UPDATE alunos SET Nome = ?, Senha = ? WHERE AlunoID = ?";
    $stmtUpdate = $conn->prepare($sqlUpdate);

    if ($stmtUpdate) {
        // Binds dos parâmetros
        $stmtUpdate->bind_param("ssi", $novoNome, $novaSenha, $alunoID);

        // Executar a atualização
        if ($stmtUpdate->execute()) {
            echo "Perfil atualizado com sucesso.";
        } else {
            echo "Erro ao atualizar o perfil: " . $stmtUpdate->error;
        }

        $stmtUpdate->close();
    } else {
        echo "Erro na preparação da consulta: " . $conn->error;
    }

    // Redirecionar de volta para o index.php após a atualização
    header("Location: index.php");
    exit();
}

// Selecionar informações do aluno
$sqlSelectAluno = "SELECT * FROM alunos WHERE AlunoID = ?";
$stmtSelectAluno = $conn->prepare($sqlSelectAluno);

if ($stmtSelectAluno) {
    $stmtSelectAluno->bind_param("i", $alunoID);

    if ($stmtSelectAluno->execute()) {
        $resultAluno = $stmtSelectAluno->get_result();

        if ($resultAluno && $resultAluno->num_rows > 0) {
            $aluno = $resultAluno->fetch_assoc();
        } else {
            echo "Nenhum aluno encontrado ou erro na obtenção do resultado: " . $stmtSelectAluno->error;
        }
    } else {
        echo "Erro na execução da consulta: " . $stmtSelectAluno->error;
    }

    $stmtSelectAluno->close();
} else {
    echo "Erro na preparação da consulta: " . $conn->error;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Perfil</title>
    <style>
        body {
            background-image: url('img/fundoadmin.jpg');
            background-size: 100%;
            font-family: Arial, sans-serif; /* Escolha uma fonte apropriada */
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        #content {
            text-align: center;
            background-color: rgba(255, 255, 255, 0.8); /* Adicione um fundo branco translúcido */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3); /* Adicione uma sombra leve */
        }

        h2 {
            color: #333; /* Cor do texto */
            background-color: #eee; /* Cor de fundo */
            padding: 10px; /* Espaçamento interno */
            border-radius: 5px;
        }

        img {
            width: 100px; /* Ajuste o tamanho conforme necessário */
            height: auto; /* Isso mantém a proporção da imagem */
            border-radius: 50%;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        label {
            margin-bottom: 5px;
        }

        input {
            margin-bottom: 10px;
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            width: 100%;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #e50914; /* Cor de fundo do botão */
            color: #fff; /* Cor do texto no botão */
            cursor: pointer;
        }
        .voltarbtn{
            background-color: #e50914; /* Cor de fundo do botão */
            color: #fff; /* Cor do texto no botão */
            cursor: pointer;
            padding: 8px;
            width: 100%;
            margin-bottom: 10px;
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        input[type="file"]{
            color: black; /* Cor do texto no botão */
            cursor: pointer;
        }
        
    </style>
</head>
<body>
    <div id="content">
        <h2>Editar Perfil</h2>

        <!-- Exibição da imagem -->
        <?php if (isset($aluno['imagem_path'])) : ?>
            <img src="<?php echo $aluno['imagem_path'] ?>" alt="Imagem do Perfil">
        <?php endif; ?>

        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
            <label for="novo_nome">Novo Nome:</label>
            <input type="text" name="novo_nome" value="<?php echo $aluno['Nome']; ?>">

            <label for="nova_senha">Nova Senha:</label>
            <input type="password" name="nova_senha">

            <label class = imagembtn for="nova_imagem">Nova Imagem:</label>
            <input type="file" name="nova_imagem">

            <input type="submit" value="Salvar">
            <a href="index.php">
            <button class="voltarbtn">Voltar</button>
            </a>
        </form>
    </div>
</body>
</html>
