document.addEventListener("DOMContentLoaded", function () {
    const chatContent = document.getElementById("chat-content");
    const userInput = document.getElementById("user-input");
    const chatBox = document.getElementById('chat-box');
    const formContainer = document.getElementById("user-question-form");
    const showFormButton = document.getElementById("show-form-button");

    let conversaEncerrada = false;

    document.getElementById('assistant-container').addEventListener('click', toggleChatBox);

    userInput.addEventListener("keydown", handleUserInput);

    showFormButton.addEventListener("click", toggleFormContainer);

    document.addEventListener("click", closeUserItems);

    // Lista fictícia de perguntas e respostas
    const faq = [
        { pergunta: "Como faço para me matricular em uma das disciplinas?", resposta: "Você pode se matricular online no portal do aluno." },
        { pergunta: "Quais são os documentos necessários para a matrícula?", resposta: "CPF ou documento contendo o número do CPF; foto 3X4 de rosto recente, fundo neutro; documento de quitação com o serviço militar para brasileiros maiores de 18 anos do sexo masculino; histórico escolar completo do Ensino Médio (frente e verso);" },
        { pergunta: "Qual é a grade curricular do curso de Ciências da Computação?", resposta: "A grade curricular pode ser encontrada no site oficial da instituição." },
        { pergunta: "Existem atividades extracurriculares disponíveis?", resposta: "Sim, oferecemos uma variedade de atividades extracurriculares, incluindo clubes e eventos." },
        { pergunta: "Olá, como você está?", resposta: "Oi! Estou bem, obrigado. E você?" },
        { pergunta: "Tudo bem por aí?", resposta: "Sim, tudo tranquilo. E contigo?" },
        { pergunta: "Como foi o seu dia?", resposta: "Foi produtivo, obrigado por perguntar. E o seu?" },
        { pergunta: "O que você tem feito ultimamente?", resposta: "Tenho trabalhado bastante. E você?" },
        { pergunta: "Alguma novidade?", resposta: "Nada de muito novo. E por aí?" },
        { pergunta: "Qual é o seu filme favorito?", resposta: "Gosto muito de [Nome do Filme]. E você, tem um favorito?" },
        { pergunta: "Que tipo de música você curte?", resposta: "Sou fã de [Gênero Musical]. E você?" },
        { pergunta: "O que você faz nas horas vagas?", resposta: "Costumo ler e assistir séries. E você?" },
        { pergunta: "Já viajou para algum lugar especial?", resposta: "Sim, já fui para [Destino]. E você?" },
        { pergunta: "Tem algum hobby interessante?", resposta: "Gosto de [Hobby]. E você?" },
        { pergunta: "Como você lida com o estresse?", resposta: "Costumo fazer exercícios para relaxar. E você?" },
        { pergunta: "Qual é a sua comida favorita?", resposta: "Adoro [Comida Favorita]. E você?" },
        { pergunta: "Você pratica algum esporte?", resposta: "Faço [Esporte]. E você?" },
        { pergunta: "Qual é o seu livro preferido?", resposta: "Um dos meus favoritos é [Nome do Livro]. E você?" },
        { pergunta: "Como você aprendeu [habilidade]?", resposta: "Aprendi [Habilidade] através de cursos online. E você?" },
        { pergunta: "Tem algum projeto interessante em andamento?", resposta: "Estou trabalhando em [Projeto]. E você?" },
        { pergunta: "Qual é o seu animal de estimação?", resposta: "Tenho um [Tipo de Animal]. E você?" },
        { pergunta: "Como você se motiva no trabalho?", resposta: "Costumo definir metas e recompensar-me ao alcançá-las. E você?" },
        { pergunta: "O que você acha de [Tópico Atual]?", resposta: "Acho [Opinião sobre o Tópico]. E você?" },
        { pergunta: "Gosta de assistir esportes?", resposta: "Sim, assisto [Nome do Esporte]. E você?" },
        { pergunta: "Qual é o seu sonho de viagem?", resposta: "Meu sonho é visitar [Destino dos Sonhos]. E você?" },
        { pergunta: "Você acredita em [Tópico Específico]?", resposta: "Sim/Não, porque [Razão]. E você?" },
        { pergunta: "Já teve alguma experiência interessante recentemente?", resposta: "Sim, tive uma experiência incrível em [Descrição]. E você?" },
        { pergunta: "Gosta de café ou chá?", resposta: "Prefiro [Café/Chá]. E você?" },
        { pergunta: "Como você lida com o tempo livre?", resposta: "Costumo fazer [Atividade] nas horas vagas. E você?" },
        { pergunta: "O que você acha de tecnologia?", resposta: "Acho fascinante! E você?" },
        { pergunta: "Já teve algum momento engraçado ultimamente?", resposta: "Sim, aconteceu [Descrição Engraçada]. E você?" },
        { pergunta: "Como você mantém o equilíbrio entre trabalho e vida pessoal?", resposta: "Faço [Atividade] para relaxar. E você?" },
        { pergunta: "Tem algum super-herói favorito?", resposta: "Gosto muito do [Nome do Super-herói]. E você?" },
        { pergunta: "Qual é o seu aplicativo favorito?", resposta: "Uso bastante o [Nome do Aplicativo]. E você?" },
        { pergunta: "Você gosta de cozinhar?", resposta: "Sim, adoro cozinhar [Tipo de Culinária]. E você?" },
        { pergunta: "Como você define sucesso?", resposta: "Para mim, sucesso é [Sua Definição]. E você?" },
        { pergunta: "Qual é o seu maior medo?", resposta: "Tenho receio de [Maior Medo]. E você?" },
        { pergunta: "Como você se imagina daqui a 5 anos?", resposta: "Gostaria de [Meta para o Futuro]. E você?" },
        { pergunta: "O que te faz sorrir?", resposta: "Pequenos gestos e momentos felizes. E você?" },
        { pergunta: "Você pratica alguma atividade artística?", resposta: "Sim, gosto de [Atividade Artística]. E você?" },
        { pergunta: "Qual é o seu lugar favorito na sua cidade?", resposta: "Gosto de [Local Favorito]. E você?" },
        { pergunta: "Como você escolheu sua profissão?", resposta: "Escolhi [Profissão] porque [Razão]. E você?" },
        { pergunta: "Já teve alguma experiência marcante em viagens?", resposta: "Sim, quando estive em [Destino]. E você?" },
        { pergunta: "Como você se mantém motivado(a) diariamente?", resposta: "Foco em [Fonte de Motivação]. E você?" },
        { pergunta: "Já participou de algum evento especial recentemente?", resposta: "Sim, estive no [Nome do Evento]. E você?" },
        { pergunta: "Qual é a sua estação do ano preferida?", resposta: "Adoro a [Estação do Ano]. E você?" },
        { pergunta: "O que você faz para se manter saudável?", resposta: "Pratico [Hábito Saudável]. E você?" },
        { pergunta: "Qual é o seu programa de TV atual favorito?", resposta: "Estou assistindo [Nome do Programa]. E você?" },
        { pergunta: "Você gosta de jardinagem?", resposta: "Sim, tenho um pequeno jardim em casa. E você?" },
        { pergunta: "O que te inspira na vida?", resposta: "A busca por [Fonte de Inspiração]. E você?" },
        { pergunta: "Você tem alguma tradição familiar especial?", resposta: "Sim, temos a tradição de [Descrição da Tradição]. E você?" },
        { pergunta: "Já teve alguma conquista recente que gostaria de compartilhar?", resposta: "Sim, recentemente alcancei [Conquista]. E você?" },
        { pergunta: "Oiii", resposta: "Oi tudo bem?" },
        // Adicione mais perguntas e respostas conforme necessário
];

    function toggleChatBox() {
        chatBox.style.display = (chatBox.style.display === 'none' || chatBox.style.display === '') ? 'block' : 'none';
    }

    function handleUserInput(e) {
        if (e.key === "Enter") {
            const userQuestion = userInput.value;
            appendMessage("Você: " + userQuestion, "user");

            if (conversaEncerrada) {
                appendMessage("Assistente: Posso ajudar com mais alguma coisa?", "assistant");
                conversaEncerrada = false;
            } else {
                answerQuestion(userQuestion);
            }

            userInput.value = "";
        }
    }

    function toggleFormContainer() {
        if (formContainer.style.display === "none" || formContainer.style.display === "") {
            formContainer.style.display = "block";
            showFormButton.textContent = "Esconder Formulário";
        } else {
            formContainer.style.display = "none";
            showFormButton.textContent = "Exibir Formulário";
        }
    }

    function toggleUserItems() {
        var userItems = document.getElementById("userItems");
        userItems.classList.toggle("show");
    }
    
    // Adicione este trecho ao seu código existente para lidar com o clique na imagem
    document.getElementById("adminImage").addEventListener("click", function() {
        toggleUserItems();
    });
    

    function appendMessage(message, sender) {
        const messageElement = document.createElement("div");
        messageElement.className = "message " + sender;
        messageElement.innerText = message;
        chatContent.appendChild(messageElement);
        chatContent.scrollTop = chatContent.scrollHeight;
    }

    function answerQuestion(question) {
        const answer = getAnswer(question);
        appendMessage("Assistente: " + answer, "assistant");

        setTimeout(function () {
            appendMessage("Assistente: Você tem mais alguma dúvida?", "assistant");
            conversaEncerrada = true;
        }, 1000);
    }

    function getAnswer(question) {
        if (question.toLowerCase().includes("como posso")) {
            return "Para interagir comigo, você pode fazer perguntas como 'Como posso fazer algo?'.";
        }

        const foundAnswer = findPartialMatch(question, faq);

        return foundAnswer ? foundAnswer.resposta : "Desculpe, não tenho uma resposta para isso.";
    }

    function findPartialMatch(userQuestion, faq) {
        return faq.find(entry => entry.pergunta.toLowerCase().includes(userQuestion.toLowerCase()));
    }

    function closeUserItems(event) {
        const adminImage = document.getElementById("adminImage");
        const userItems = document.getElementById("userItems");

        if (event.target !== adminImage && event.target.parentNode !== adminImage) {
            userItems.classList.remove("show");
        }
    }

           // Adicione um script JavaScript para mostrar/ocultar a lista ao clicar na imagem
    const adminImage = document.getElementById('adminImage');
    const infoList = document.querySelector('.user-items');

    adminImage.addEventListener('click', function() {
        // Alternar a visibilidade da lista
        infoList.style.display = infoList.style.display === 'none' ? 'block' : 'none';
    });
       


       function buscar() {
        // Obtém a consulta de pesquisa do input
        var query = document.getElementById('searchInput').value;
    
        // Realiza uma requisição AJAX para buscar.php
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // Parseia a resposta JSON
                var resultados = JSON.parse(xhr.responseText);
    
                // Atualiza a div de resultados
                exibirResultados(resultados);
            }
        };
    
        // Configura a requisição AJAX
        xhr.open('GET', '/buscar.php?q=' + encodeURIComponent(query), true);
        xhr.send();
    }
    
    function exibirResultados(resultados) {
        // Obtém a div de resultados
        var resultadoDiv = document.getElementById('resultadoPesquisa');
    
        // Limpa a div de resultados
        resultadoDiv.innerHTML = '';
    
        // Itera sobre os resultados e os adiciona à div
        resultados.forEach(function (resultado) {
            if (resultado.pergunta) {
                resultadoDiv.innerHTML += 'Pergunta: ' + resultado.pergunta + '<br>';
                // Adicione outras informações relevantes que você deseja exibir
            } else if (resultado.mensagem) {
                resultadoDiv.innerHTML += resultado.mensagem + '<br>';
            }
        });
    }


    
});