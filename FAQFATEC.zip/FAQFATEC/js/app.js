const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const ejs = require('ejs');

const app = express();
const port = 3000;

// Configuração do MySQL
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'faqfatec'
});

connection.connect(err => {
    if (err) {
        console.error('Erro de conexão ao MySQL:', err);
        return;
    }
    console.log('Conectado ao MySQL');
});

app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');

// Rota principal do painel de administração
app.get('/admin', (req, res) => {
    // Recupere perguntas do banco de dados
    connection.query('SELECT * FROM perguntas', (err, results) => {
        if (err) throw err;

        res.render('admin', { perguntas: results });
    });
});

// Adicione outras rotas para editar, aprovar, etc.

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
