-- Criar a tabela de Categorias
CREATE TABLE Categorias (
    CategoriaID INT PRIMARY KEY,
    NomeCategoria VARCHAR(50) NOT NULL
);

-- Inserir algumas categorias iniciais
INSERT INTO Categorias (CategoriaID, NomeCategoria)
VALUES
    (1, 'Matrícula'),
    (2, 'Grade Curricular'),
    (3, 'Atividades Extracurriculares');

-- Criar a tabela de Perguntas
CREATE TABLE Perguntas (
    PerguntaID INT PRIMARY KEY,
    CategoriaID INT,
    PerguntaTexto TEXT NOT NULL,
    FOREIGN KEY (CategoriaID) REFERENCES Categorias(CategoriaID)
);

-- Inserir algumas perguntas
INSERT INTO Perguntas (PerguntaID, CategoriaID, PerguntaTexto)
VALUES
    (1, 1, 'Como faço para me matricular?'),
    (2, 1, 'Quais são os documentos necessários para a matrícula?'),
    (3, 2, 'Qual é a grade curricular do curso de Ciências da Computação?'),
    (4, 3, 'Existem atividades extracurriculares disponíveis?');

-- Criar a tabela de Respostas
CREATE TABLE Respostas (
    RespostaID INT PRIMARY KEY,
    PerguntaID INT,
    RespostaTexto TEXT NOT NULL,
    FOREIGN KEY (PerguntaID) REFERENCES Perguntas(PerguntaID)
);

-- Inserir algumas respostas
INSERT INTO Respostas (RespostaID, PerguntaID, RespostaTexto)
VALUES
    (1, 1, 'Você pode se matricular online no portal do aluno.'),
    (2, 1, 'Os documentos necessários incluem RG, CPF e comprovante de residência.'),
    (3, 2, 'A grade curricular pode ser encontrada no site oficial da instituição.'),
    (4, 3, 'Sim, oferecemos uma variedade de atividades extracurriculares, incluindo clubes e eventos.');

